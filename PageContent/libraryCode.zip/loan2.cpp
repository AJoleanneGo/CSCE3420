#include <iostream>
#include <string>
#include <vector>

#include "loan.h"
#include "loan2.h"

using namespace std;

int LoanCollection::GetNumOverdue(){
	int numOverdue = 0;
	for(int i = 0; i < collection.size(); i++){
		if(collection.at(i).GetCurrentStatus() == "Overdue")
			numOverdue++;
	}

	return numOverdue;
}

void LoanCollection::AddLoan(Loan l){
	collection.push_back(l);
}

void LoanCollection::DeleteLoan(Loan l){
        bool found = false;
        for(int i = 0; i < collection.size(); ++i){
                if(collection.at(i).GetLoanID() == l.GetLoanID()){
                        collection.erase(collection.begin() + i);
                        found = true;
                }
        }

        if(!found){
                cout << "Loan " << l.GetLoanID() << " does not exist" << endl;
        }
}

Loan LoanCollection::FindLoan(Loan l){
	Loan toReturn;
	bool found = false;
	for(int i = 0; i < collection.size(); i++){
		if(l.GetItemID() == collection.at(i).GetItemID()){
			toReturn = collection.at(i);
			found = true;
		}
		if(l.GetLoanID() == collection.at(i).GetLoanID()){
			toReturn = collection.at(i);
                        found = true;
		}
	}

	if(found){
		return toReturn;
	}
	else{
		toReturn = l;
		cout << "Loan does not exist." << endl;
		return toReturn;
	}
}

void LoanCollection::EditLoan(Loan l){
	 for(int i = 0; i < collection.size(); i++){
		if(l.GetLoanID() == collection.at(i).GetLoanID()){
                        collection.at(i) = l;
                }
	}
}

void LoanCollection::PayFines(){
	bool fines = false;
	double total = 0;
	double fine = 0;
	for(int i = 0; i < collection.size(); i++){
		if(collection.at(i).GetCurrentStatus() == "Overdue"){
			fine = collection.at(i).GetNumDaysLate() * FINE_PER_DAY;
			cout << "Loan " << collection.at(i).GetLoanID() << endl;
			cout << "Number of Days Late: " << collection.at(i).GetNumDaysLate() << endl;
			cout << "Fine: $" << fine << endl;
			cout << endl;
			total += fine;
			fines = true;
		}
	}

	if(fines){
		cout << "Total Fines: $" << total << endl;
	}

	else{
		cout << "No Fines to be paid" << endl;
	}
}
