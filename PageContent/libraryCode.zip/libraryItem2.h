#ifndef ITEM_COLLECTION_H
#define ITEM_COLLECTION_H

#include <string>
#include <vector>

#include "libraryItem.h"
#include "book.h"
#include "cd.h"
#include "dvd.h"

using namespace std;

class LibraryItemCollection{
        private:
                vector <LibraryItem> collection;

        public:
                int GetNumItems();
                void AddItem(LibraryItem l);
                void DeleteItem(LibraryItem l);
                LibraryItem FindItem(LibraryItem l);
                void ListOverdue();
                void PrintCollection();
                void EditItem(LibraryItem l);
};

#endif


