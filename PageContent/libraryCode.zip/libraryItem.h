#ifndef LIBRARY_ITEM_H
#define LIBRARY_ITEM_H

#include <string>
using namespace std;

class LibraryItem{
	private:
		string id;
		string title;
		double cost;
		string status;
		int loanPeriod;

	public:
		string GetID();
		string GetTitle();
		double GetCost();
		string GetStatus();
		int GetLoanPeriod();

		void SetID(string newID);
		void SetTitle(string newTitle);
		void SetCost(double newCost);
		void SetStatus(string newStatus);
		void SetLoanPeriod(int newLoanPeriod);

		void PrintAll();
};

#endif
