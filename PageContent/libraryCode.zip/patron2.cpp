#include <string>
#include <vector>
#include <iostream>
#include <ctime>
#include <cstdlib>

#include "patron2.h"
using namespace std;

void PatronData::CheckIn(time_t currentTime, Loan l){
	Loan in = lc.FindLoan(l);
	char response;
	double fine;
	LibraryItem li;
	if(in.GetCurrentStatus() == "Overdue"){
		fine = in.GetNumDaysLate() * 0.25;
		cout << "Item is overdue." << endl;
		cout << "Total Fine: $" << fine << endl;
		cout << "Would you like to pay fine? (y/n) ";
		cin >> response;
		if(response == 'y'){
			cout << "Fine has been paid." << endl;
			this->SetFineBalance(this->GetFineBalance() - fine);
			cout << "Current Balance: " << this->GetFineBalance() << endl;
			li.SetID(in.GetItemID());
			c.DeleteItem(li);
			lc.DeleteLoan(in);

			cout << "Item has been checked in" << endl;
	        }
		else{
                        cout << "Fine has not been paid. Item has been checked in." << endl;
			li.SetID(in.GetItemID());
                        c.DeleteItem(li);
                }

	}
}

void PatronData::CheckOut(time_t currentTime, LibraryItem l, string loanID){
	Loan temp = Loan();
        if(c.GetNumItems() < 6){
                //adds book
                l.SetStatus("Out");
                c.AddItem(l);

                //creates and adds loan
                temp.SetLoanID(loanID);
                temp.SetItemID(l.GetID());
                temp.SetPatronID(this->GetPatronID());
                temp.SetDueDateTime(currentTime + (60*60*24*10));
                lc.AddLoan(temp);

		cout << "Item will be due in 10 days" << endl;
	}

        else{
                cout << "Currently borrowed the maximum amount of books" << endl;
        }
}

void PatronData::ReportLost(LibraryItem l){
	LibraryItem lost = c.FindItem(l);
	char response;
	cout << "Library ID: " << lost.GetID() << endl;
	cout << "The item costs $" << lost.GetCost() << endl;
	cout << "Would you like to pay fine? (y/n) ";
                cin >> response;
                if(response == 'y'){
                        cout << "Fine had been paid." << endl;
                        this->SetFineBalance(this->GetFineBalance() - lost.GetCost());
                        cout << "Current Balance: " << this->GetFineBalance() << endl;
			lost.SetStatus("Lost");
			c.EditItem(lost);
		}
		else{
			cout << "Please pay the fine before reporting it lost" << endl;
		}

}

void PatronData::RenewCheckOut(Loan l){
	Loan renew = lc.FindLoan(l);
	if(renew.GetRenewed()){
		cout << "Item has already been renewed" << endl;
	}
	else{
		renew.SetDueDateTime(renew.GetDueDateTime() + (60*60*24*10));
		renew.SetRenewed(true);
		cout << "Item has been renewed." << endl;
		cout << "New due date and time: " << renew.GetDueDateTime() << endl;

		lc.EditLoan(renew);
	}
}





