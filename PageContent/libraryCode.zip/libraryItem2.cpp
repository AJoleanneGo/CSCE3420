#include <iostream>
#include <vector>
#include <string>

#include "libraryItem2.h"
using namespace std;

int LibraryItemCollection::GetNumItems(){
        return collection.size();
}

void LibraryItemCollection::AddItem(LibraryItem l){
        collection.push_back(l);
}

void LibraryItemCollection::DeleteItem(LibraryItem l){
        bool found = false;
        for(int i = 0; i < collection.size(); ++i){
                if(collection.at(i).GetID() == l.GetID()){
                        collection.erase(collection.begin() + i);
                        found = true;
                }
                if(collection.at(i).GetTitle() == l.GetTitle()){
                        collection.erase(collection.begin() + i);
                        found = true;
                }
        }

        if(!found){
                cout << l.GetTitle() << " is not in collection" << endl;
        }
        else{
                cout << l.GetTitle() << " has been removed" << endl;
        }
}

LibraryItem LibraryItemCollection::FindItem(LibraryItem l){
        LibraryItem toReturn;
        bool found = false;
        for(int i = 0; i < collection.size(); i++){
                if(collection.at(i).GetID() == l.GetID()){
                        toReturn = collection.at(i);
                        found = true;
                }
                if(collection.at(i).GetTitle() == l.GetTitle()){
                        toReturn = collection.at(i);
		}
	}

        if(!found){
                cout << l.GetTitle() << " is not in collection" << endl;
        }

        return toReturn;
}

void LibraryItemCollection::ListOverdue(){
        bool overdue = false;
        for(int i = 0; i < collection.size(); i++){
                if(collection.at(i).GetStatus() == "Overdue"){
                        collection.at(i).PrintAll();
                        overdue = true;
                }
        }

        if(!overdue){
                cout << "No books overdue" << endl;
        }
}

void LibraryItemCollection::PrintCollection(){
        for(int i = 0; i < collection.size(); i++){
                collection.at(i).PrintAll();
                cout << endl;
        }
}

void LibraryItemCollection::EditItem(LibraryItem l){
        for(int i = 0; i < collection.size(); i++){
                if(l.GetID() == collection.at(i).GetID()){
                        collection.at(i) = l;
                }
        }
}




