#ifndef CD_H
#define CD_H

#include <string>
#include "libraryItem.h"

using namespace std;

class AudioCD : public LibraryItem{
	private:
		string artist;
		int tracks;
		string releaseDate;
		string genre;

	public:
		string GetArtist();
		int GetTracks();
		string GetReleaseDate();
		string GetGenre();

		void SetArtist(string newArtist);
		void SetTracks(int newTracks);
		void SetReleaseDate(string newDate);
		void SetGenre(string newGenre);

		void PrintAll();
};
#endif
