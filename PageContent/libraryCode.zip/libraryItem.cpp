#include <iostream>
#include <string>

#include "libraryItem.h"
using namespace std;

string LibraryItem::GetID(){
	return id;
}

string LibraryItem::GetTitle(){
	return title;
}

double LibraryItem::GetCost(){
	return cost;
}

string LibraryItem::GetStatus(){
	return status;
}

int LibraryItem::GetLoanPeriod(){
	return loanPeriod;
}

void LibraryItem::SetID(string newID){
	id = newID;
}

void LibraryItem::SetTitle(string newTitle){
	title = newTitle;
}

void LibraryItem::SetCost(double newCost){
	cost = newCost;
}

void LibraryItem::SetStatus(string newStatus){
	status = newStatus;
}

void LibraryItem::SetLoanPeriod(int newLoanPeriod){
	loanPeriod = newLoanPeriod;
}

void LibraryItem::PrintAll(){
	cout << "Library ID Number: " << id << endl;
	cout << "Cost: " << cost << endl;
	cout << "Status: " << status << endl;
	cout << "Loan Period: " << loanPeriod << endl;
	cout << endl;
}


