#ifndef PATRON_H
#define PATRON_H

#include <string>

using namespace std;

class Patron{
        private:
                string name;
                string patronID;
                double fineBalance;
                int numCheckedOut;
        public:
                string GetName();
                string GetPatronID();
                double GetFineBalance();
                int GetNumCheckedOut();

                void SetName(string n);
                void SetPatronID(string p);
                void SetFineBalance(double f);
                void SetNumCheckedOut(int nc);

		void PrintPatron();
                Patron();
                Patron(string n, string p, double f, int nc);
};

#endif
