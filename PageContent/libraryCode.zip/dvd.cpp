#include <iostream>
#include <string>

#include "libraryItem.h"
#include "dvd.h"
using namespace std;

string DVD::GetCategory(){
	return category;
}

string DVD::GetRuntime(){
	return runtime;
}

string DVD::GetStudio(){
	return studio;
}

string DVD::GetReleaseDate(){
	return releaseDate;
}

void DVD::SetCategory(string newCategory){
	category = newCategory;
}

void DVD::SetRuntime(string newRuntime){
	runtime = newRuntime;
}

void DVD::SetStudio(string newStudio){
	studio = newStudio;
}

void DVD::SetReleaseDate(string newDate){
	releaseDate = newDate;
}

void DVD::PrintAll(){
	cout << "Title: " << this->GetTitle() << endl;
        cout << "Library ID Number: " << this->GetID() << endl;
        cout << "Cost: " << this->GetCost() << endl;
        cout << "Status: " << this->GetStatus() << endl;
        cout << "Loan Period: " << this->GetLoanPeriod() << endl;
        cout << endl;
	cout << "==DVD Information==" << endl;
	cout << "Category: " << category << endl;
	cout << "Runtime: " << runtime << endl;
	cout << "Studio: " << studio << endl;
	cout << "Release Date: " << releaseDate << endl;
	cout << endl;
}

