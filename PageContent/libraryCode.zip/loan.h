#ifndef LOAN_H
#define LOAN_H

#include <string>
#include <ctime>
using namespace std;

class Loan{
	private:
		string loanID;
		string itemID;
		string patronID;
		time_t dueDateTime;
		string currentStatus;
		bool renewed;
		int numDaysLate;
	public:
		//accessor
		string GetLoanID();
		string GetItemID();
		string GetPatronID();
		time_t GetDueDateTime();
		string GetCurrentStatus();
		bool GetRenewed();
		int GetNumDaysLate();

		//mutator
		void SetLoanID(string loan);
		void SetItemID(string item);
		void SetPatronID(string patron);
		void SetDueDateTime(time_t dateTime);
		void SetCurrentStatus(string status);
		void SetRenewed(bool ren);
		void SetNumDaysLate(int days);

		//constructors
		Loan();
		Loan(string l, string i, string p, time_t d, string c, bool r, int n);
};

#endif
