#include <iostream>
#include <vector>
#include <cstring>
#include <ctime>
#include <cstdlib>

#include "libraryItem2.h"
#include "patron2.h"
#include "loan2.h"
#include "menu.h"
using namespace std;

void PatronLogIn(vector<PatronData> &database){
        //declaration
        char condition;
        PatronData temp;
        bool unique = true;
        int logInOption;
        double balance;
        string patronName;
        string patronID;
        do{
                cout << "1. Create an Account" << endl;
                cout << "2. Log in to Existing Account" << endl;
                cout << endl;
                cout << "Enter 1 or 2: "; cin >> logInOption;

                if(logInOption == 1){
                        cout << "===NEW ACCOUNT===" << endl;
			cin.ignore();
                        cout << "Enter your name: "; getline(cin, patronName);
                        temp.SetName(patronName);
                        //tests if patron ID is unique
                        do{
                                unique = true;
                                cout << "Enter a unique PatronID: "; cin >> patronID;
                                for(int i = 0; i < database.size(); i++){
                                        if(database.at(i).GetPatronID() == patronID){
                                                cout << "Patron ID is already in use. Please enter a different ID" << endl;
                                                unique = false;
                                        }
                                }
                        }while(!unique);
                        temp.SetPatronID(patronID);
                        cout << "Enter your balance: "; cin >> balance;
                        temp.SetFineBalance(balance);
                        database.push_back(temp);
                }
                if(logInOption == 2){
                        cout << "===EXISTING USER===" << endl;
                        //checking for patron ID of the same name
                        do{
                                unique = true;
                                cout << "Enter patron ID: "; cin >> patronID;
                                for(int i = 0; i < database.size(); i++){
                                        if(database.at(i).GetPatronID() == patronID){
                                                cout << "Welcome " << database.at(i).GetName() << " !" << endl;
                                                condition = AccountMenu(database.at(i));
                                                unique = false;
                                        }
                                }
                                if(unique){
                                        cout << "We could not find an account with that ID." << endl;
                                        cout << "Press space to try again, or press x to exit." << endl;
                                        cin >> condition;
                                }
                        }while(unique && condition != 'x');
                }
        }while(condition != 'x' || logInOption > 2 || logInOption < 1);
}

int main(){
	vector<PatronData> database;
	PatronLogIn(database);

	return 0;
}
