#include <iostream>
#include <string>
using namespace std;

#include "patron.h"

Patron::Patron(){
        name = "";
        patronID = "";
        fineBalance = 0;
        numCheckedOut = -1;

}

Patron::Patron(string n, string p, double f, int nc){
        name = n;
        patronID = p;
        fineBalance = f;
        numCheckedOut = nc;

}

string Patron::GetName(){
        return name;
}
string Patron::GetPatronID(){
        return patronID;
}
double Patron::GetFineBalance(){
        return fineBalance;
}
int Patron::GetNumCheckedOut(){
        return numCheckedOut;
}

void Patron::SetName(string n){
	name = n;
}
void Patron::SetPatronID(string p){
	patronID = p;
}
void Patron::SetFineBalance(double f){
	fineBalance = f;
}
void Patron::SetNumCheckedOut(int nc){
	numCheckedOut = nc;
}

void Patron::PrintPatron(){
	cout << "===PATRON INFO===" << endl;
	cout << "Patron Name: " << name << endl;
	cout << "Patron ID: " << patronID << endl;
	cout << "Fine Balance: $" << fineBalance << endl;
}
