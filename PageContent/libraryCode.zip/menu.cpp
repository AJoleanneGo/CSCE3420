#include <iostream>
#include <vector>
#include <cstring>
#include <ctime>
#include <cstdlib>

#include "libraryItem2.h"
#include "patron2.h"
#include "loan2.h"

using namespace std;

char AccountMenu(PatronData &data){
	//declarations
	int menu;
	int checkOut;
	string loanID;
	Loan tempLoan;
	Book tempBook;
	AudioCD tempCD;
	DVD tempDVD;
	LibraryItem tempItem;

	//for check out
	string libraryID;
	string title;
	string author;
	int number;
	string date;
	string category;
	string genre;
	int tracks;
	string runtime;

	//rand
	int numLoan = data.c.GetNumItems();
	time_t currentTime = time(0);
	char condition;
	do{
		cout << "Library Menu" << endl;
		cout << "1 - View Profile" << endl;
		cout << "2 - Print Collection" << endl;
		cout << "3 - Check In" << endl;
		cout << "4 - Check Out" << endl;
		cout << "5 - Print Overdue" << endl;
		cout << "6 - Pay Fines" << endl;
		cout << "7 - Report Item Lost" << endl;
		cout << "8 - Renew Item" << endl;
		cout << "0 - Quit " << endl;
		cout << endl;
		cout << "Enter option number: "; cin >> menu;

		//options
		switch(menu){
			case 1:
				data.PrintPatron();
				cout << endl;
				break;
			case 2:
				cout << "===ITEM COLLECTION===" << endl;
				data.c.PrintCollection();
				cout << endl;
				break;
			case 3:
				cout << "===CHECK IN===" << endl;
				cout << "Enter Library ID: "; cin >> loanID;
				tempLoan.SetItemID(loanID);
				data.CheckIn(currentTime, tempLoan);
				cout << endl;
				break;
			case 4:
				loanID = data.GetName().substr(0,2) + data.GetPatronID() + to_string(numLoan);
				numLoan++;
				cout << "===CHECK OUT===" << endl;
				cout << "1 - Book" << endl;
				cout << "2 - CD" << endl;
				cout << "3 - DVD" << endl;
				cout << endl;
				cout << "Enter the number of the item you will check out: "; cin >> checkOut;
				cout << endl;
				cout << "Enter Library ID: "; cin >> libraryID;
				cin.ignore();
				cout << "Enter Title: ";  getline(cin, title);
				if(checkOut == 1){
					tempBook.SetID(libraryID);
					tempBook.SetTitle(title);
					tempBook.SetCost(19.99);
					tempBook.SetStatus("Out");
					cin.ignore();
					cout << "Enter Author Name: "; getline(cin, author);
					tempBook.SetAuthor(author);
					cout << "Enter ISBN Number: "; cin >> number;
					tempBook.SetISBNNumber(number);
					cout << "Enter Category: "; cin >> category;
					tempBook.SetCategory(category);
					data.CheckOut(currentTime, tempBook, loanID);
				}
				if(checkOut == 2){
					tempCD.SetID(libraryID);
					tempCD.SetTitle(title);
                                        tempCD.SetCost(19.99);
                                        tempCD.SetStatus("Out");
					cin.ignore();
					cout << "Enter Artist Name: "; getline(cin, author);
					tempCD.SetArtist(author);
					cout << "Enter Number of Tracks: "; cin >> tracks;
					tempCD.SetTracks(tracks);
					cin.ignore();
					cout << "Enter Release Date: "; getline(cin, date);
					tempCD.SetReleaseDate(date);
					cin.ignore();
					cout << "Enter Genre: "; getline(cin, genre);
					tempCD.SetGenre(genre);
					data.CheckOut(currentTime, tempCD, loanID);
				}
				if(checkOut == 3){
					tempDVD.SetID(libraryID);
					tempDVD.SetTitle(title);
                                        tempDVD.SetCost(19.99);
                                        tempDVD.SetStatus("Out");
					cout << "Enter Category: "; cin >> category;
					tempDVD.SetCategory(category);
					cin.ignore();
					cout << "Enter Studio: "; getline(cin, author);
					tempDVD.SetStudio(author);
					cout << "Enter Run time: "; cin >> runtime;
					tempDVD.SetRuntime(runtime);
					cin.ignore();
					cout << "Enter Release Date: "; getline(cin, date);
					tempDVD.SetReleaseDate(date);
					data.CheckOut(currentTime, tempDVD, loanID);
				}
				else{
					cout << "No Item was checked out." << endl;
				}
				cout << endl;
				break;

			case 5:
				cout << "===PRINT OVERDUE===" << endl;
				data.c.ListOverdue();
				cout << endl;
				break;
			case 6:
				cout << "===PAY FINES===" << endl;
				data.lc.PayFines();
				cout << endl;
				break;
			case 7:
				cout << "===REPORT LOST===" << endl;
				cout << "Enter Library ID: "; cin >> libraryID;
				tempItem.SetID(libraryID);
				data.ReportLost(tempItem);
				cout << endl;
				break;
			case 8:
				cout << "===RENEW ITEM===" << endl;
				cout << "Enter Loan ID"; cin >> loanID;
				tempLoan.SetLoanID(loanID);
				data.RenewCheckOut(tempLoan);
				cout << endl;
				break;
			case 0:
				condition = 'x';
				break;
			default:
				cout << "Please enter an number from the menu." << endl;
				cout << endl;
				break;
		}
	}while(menu != 0);
	return condition;
}
