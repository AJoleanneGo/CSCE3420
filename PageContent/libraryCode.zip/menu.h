#include <string>
#include "patron2.h"
using namespace std;

char AccountMenu(PatronData &data);
