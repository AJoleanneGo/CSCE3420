#ifndef PATRON_DATA_H
#define PATRON_DATA_H

#include <string>
#include <vector>

#include "libraryItem.h"
#include "libraryItem2.h"
#include "loan.h"
#include "loan2.h"
#include "patron.h"

using namespace std;

class PatronData: public Patron{
	public:
		void CheckIn(time_t currentTime, Loan l);
		void CheckOut(time_t currentTime, LibraryItem l, string LoanID);
		void ReportLost(LibraryItem l);
		void RenewCheckOut(Loan l);
                LibraryItemCollection c;
                LoanCollection lc;

};
#endif
