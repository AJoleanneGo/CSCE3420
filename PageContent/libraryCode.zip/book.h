#ifndef BOOK_H
#define BOOK_H

#include <string>
#include "libraryItem.h"
using namespace std;

class Book : public LibraryItem{
	private:
		string author;
		int ISBNNumber;
		string category;
	public:
		string GetAuthor();
		int GetISBNNumber();
		string GetCategory();

		void SetAuthor(string a);
                void SetISBNNumber(int i);
		void SetCategory(string c);
		void PrintAll();

		Book();
		Book(string a, int i, string c);
};

#endif
