#include <iostream>
#include <string>
using namespace std;

#include "book.h"
#include "libraryItem.h"
Book::Book(){
        author = "";
        ISBNNumber = -1;
	category = "";

}

Book::Book(string a, int i, string c){
        author = a;
        ISBNNumber = i;
        category = c;
}

string Book::GetAuthor(){
        return author;
}

int Book::GetISBNNumber(){
	return ISBNNumber;
}

string Book::GetCategory(){
	return category;
}

void Book::SetAuthor(string a){
	author = a;
}

void Book::SetISBNNumber(int i){
	ISBNNumber = i;
}

void Book::SetCategory(string c){
	category = c;
}

void Book::PrintAll(){
	cout << "Title: " << this->GetTitle() << endl;
	cout << "Library ID Number: " << this->GetID() << endl;
        cout << "Cost: " << this->GetCost() << endl;
        cout << "Status: " << this->GetStatus() << endl;
        cout << "Loan Period: " << this->GetLoanPeriod() << endl;
        cout << endl;

	cout << "==Book Information==" << endl;
	cout << "Author: " << author << endl;
	cout << "ISBN Number: " << ISBNNumber << endl;
	cout << "Category: " << category << endl;
}
