#include <iostream>
#include <string>

#include "libraryItem.h"
#include "cd.h"
using namespace std;

string AudioCD::GetArtist(){
	return artist;
}

int AudioCD::GetTracks(){
	return tracks;
}

string AudioCD::GetReleaseDate(){
	return releaseDate;
}

string AudioCD::GetGenre(){
	return genre;
}

void AudioCD::SetArtist(string newArtist){
	artist = newArtist;
}

void AudioCD::SetTracks(int newTracks){
	tracks = newTracks;
}

void AudioCD::SetReleaseDate(string newDate){
	releaseDate = newDate;
}

void AudioCD::SetGenre(string newGenre){
	genre = newGenre;
}

void AudioCD::PrintAll(){
	cout << "Title: " << this->GetTitle() << endl;
        cout << "Library ID Number: " << this->GetID() << endl;
        cout << "Cost: " << this->GetCost() << endl;
        cout << "Status: " << this->GetStatus() << endl;
        cout << "Loan Period: " << this->GetLoanPeriod() << endl;
        cout << endl;
	cout << "==CD Information==" << endl;
	cout << "Artist: " << artist << endl;
	cout << "Number of Tracks: " << tracks << endl;
	cout << "Release Date: " << releaseDate << endl;
	cout << "Genre: " << genre << endl;
}

