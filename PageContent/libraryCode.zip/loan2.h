#ifndef LOAN_COLLECTION_H
#define LOAN_COLLECTION_H

#include <string>
#include <vector>

#include "loan.h"
using namespace std;

class LoanCollection{
	private:
		const double FINE_PER_DAY = 0.25;
		vector <Loan> collection;
	public:
		int GetNumOverdue();
		void AddLoan(Loan l);
		Loan FindLoan(Loan l);
		void EditLoan(Loan l);
		void DeleteLoan(Loan l);
		void PayFines();
};

#endif
