#include <iostream>
#include <ctime>
#include <cstdlib>
#include <string>
using namespace std;

#include "loan.h"

//default constructor
Loan::Loan(){
	loanID = "";
	itemID = "";
	patronID = "";
	dueDateTime = time(0);
	currentStatus = "";
	renewed = false;
	numDaysLate = 0;
}

//parameter constructor
Loan::Loan(string l, string i, string p, time_t d, string c, bool r, int n){
	loanID = l;
        itemID = i;
        patronID = p;
        dueDateTime = d;
        currentStatus = c;
        renewed = r;
        numDaysLate = n;
}

//accessors
string Loan::GetLoanID(){
	return loanID;
}

string Loan::GetItemID(){
	return itemID;
}

string Loan::GetPatronID(){
	return patronID;
}

time_t Loan::GetDueDateTime(){
	return dueDateTime;
}

string Loan::GetCurrentStatus(){
	return currentStatus;
}

bool Loan::GetRenewed(){
	return renewed;
}

int Loan::GetNumDaysLate(){
	return numDaysLate;
}

//mutator
void Loan::SetLoanID(string loan){
	loanID = loan;
}

void Loan::SetItemID(string item){
	itemID = item;
}

void Loan::SetPatronID(string patron){
	patronID = patron;
}

void Loan::SetDueDateTime(time_t dateTime){
	dueDateTime = dateTime;
}

void Loan::SetCurrentStatus(string status){
	currentStatus = status;
}

void Loan::SetRenewed(bool ren){
	renewed = ren;
}

void Loan::SetNumDaysLate(int days){
	numDaysLate = days;
}


