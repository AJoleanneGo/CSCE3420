#ifndef DVD_H
#define DVD_H

#include <string>
#include "libraryItem.h"

using namespace std;

class DVD : public LibraryItem{
	private:
		string category;
		string runtime;
		string studio;
		string releaseDate;
	public:
		string GetCategory();
		string GetRuntime();
		string GetStudio();
		string GetReleaseDate();

		void SetCategory(string newCategory);
		void SetRuntime(string newRuntime);
		void SetStudio(string newStudio);
		void SetReleaseDate(string newDate);

		void PrintAll();
};
#endif
